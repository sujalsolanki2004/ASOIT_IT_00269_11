<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .container {
            display: flex;
            flex-direction: column;
            width: 23%
        }
    </style>
</head>

<body>
    <div class="container">
      <form method="post" action="Untitled-1.php">
        
       NUMBER 1: <input type="text" name="n1">
        <br>
    <hr>
       NUMBER 2: <input type="text" name="n2">
        <br>
        <hr>
        <button><input type="submit" name="submit"></button>
        <br>
        <hr>
        RESULT:<input type="text" name="result">
    </form>

    </div>
</body>

</html>