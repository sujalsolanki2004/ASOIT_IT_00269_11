<?php 
if(isset($_POST["submit"]))
{
    if(isset($_POST['n1']) &&  isset($_POST["n2"])){
        $n1=$_POST["n1"];
        $n2=$_POST["n2"];
        $result = $n1 + $n2;
    }
}
?>
 Result:<input type="text" name="result" value="<?php echo $result; ?>"/> 